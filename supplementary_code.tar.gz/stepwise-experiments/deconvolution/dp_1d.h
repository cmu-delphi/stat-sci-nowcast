#ifndef TF_H
#define TF_H

void tf_dp (int n, double *y, double lam, double *beta);

#endif